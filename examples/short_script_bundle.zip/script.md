# 政策变化

此前的政策于2023年推出。

## 画面提示



## 来源

- Example policy changed — https://example.com/news (2026-01-01T00:00:00Z)

## 分段引用与分镜

### 第 1 段 · 事实陈述

此前的政策于2023年推出。

来源：E1

画面：政策时间线

素材需求：公告配图

来源编号对应 sources.json；节点和固定原文见 evidence_snapshot.json。
